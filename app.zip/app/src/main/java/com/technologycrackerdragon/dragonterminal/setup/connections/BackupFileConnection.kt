package com.thecrackertechnology.dragonterminal.setup.connections

import android.content.Context
import android.net.Uri

/**
 * @author kiva
 */

class BackupFileConnection(context: Context, uri: Uri) : LocalFileConnection(context, uri)
