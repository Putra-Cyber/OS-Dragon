package com.thecrackertechnology.dragonterminal.frontend.session.shell.client.event

/**
 * @author kiva
 */
class CreateNewSessionEvent