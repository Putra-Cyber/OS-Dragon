package com.thecrackertechnology.dragonterminal.setup

/**
 * @author kiva
 */
interface ResultListener {
    fun onResult(error: Exception?)
}