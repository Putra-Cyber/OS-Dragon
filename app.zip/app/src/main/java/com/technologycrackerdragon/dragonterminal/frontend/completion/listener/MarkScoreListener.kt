package com.thecrackertechnology.dragonterminal.frontend.completion.listener

/**
 * @author kiva
 */

interface MarkScoreListener {
    fun onMarkScore(score: Int)
}
