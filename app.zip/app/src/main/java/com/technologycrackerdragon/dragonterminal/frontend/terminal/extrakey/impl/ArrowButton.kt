package com.thecrackertechnology.dragonterminal.frontend.terminal.extrakey.impl

import com.thecrackertechnology.dragonterminal.frontend.terminal.extrakey.button.RepeatableButton

/**
 * @author kiva
 */
class ArrowButton(arrowText: String) : RepeatableButton(arrowText)
