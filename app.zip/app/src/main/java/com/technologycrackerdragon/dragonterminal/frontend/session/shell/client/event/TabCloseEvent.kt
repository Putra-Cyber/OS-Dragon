package com.thecrackertechnology.dragonterminal.frontend.session.shell.client.event

import com.thecrackertechnology.dragonterminal.ui.term.tab.TermTab

/**
 * @author kiva
 */

class TabCloseEvent(var termTab: TermTab)
