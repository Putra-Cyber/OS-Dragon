package com.thecrackertechnology.dragonterminal.component.codegen

/**
 * @author kiva
 */
class CodeGenParameter