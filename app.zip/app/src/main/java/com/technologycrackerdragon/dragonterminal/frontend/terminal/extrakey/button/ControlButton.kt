package com.thecrackertechnology.dragonterminal.frontend.terminal.extrakey.button

/**
 * @author kiva
 */

open class ControlButton(text: String) : TextButton(text, false)