package com.thecrackertechnology.dragonterminal.frontend.session.xorg;

/**
 * @author kiva
 */

public class XParameter {
}
