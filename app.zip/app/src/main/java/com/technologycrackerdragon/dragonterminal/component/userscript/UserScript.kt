package com.thecrackertechnology.dragonterminal.component.userscript

import java.io.File

/**
 * @author kiva
 */
class UserScript(val scriptFile: File)