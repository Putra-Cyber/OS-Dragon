package com.thecrackertechnology.andrax;

public class DataTutorial {

    public String TutorialImage;
    public String TutorialName;
    public String Tutorialdesc;
    public String Tutoriallink;

}
