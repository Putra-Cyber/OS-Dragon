package com.thecrackertechnology.dragonterminal;

import com.thecrackertechnology.dragonterminal.xorg.NeoXorgViewClient;

/**
 * @author kiva
 */

public class NeoAudioThread extends AudioThread {
    public NeoAudioThread(NeoXorgViewClient client) {
        super(client);
    }
}
