package com.thecrackertechnology.dragonterminal;

import com.thecrackertechnology.dragonterminal.xorg.NeoXorgViewClient;

/**
 * @author kiva
 */

public class NeoXorgSettings {
    public static void init(NeoXorgViewClient client) {
        Settings.Load(client);
    }
}
