package io.neolang.ast.node

import io.neolang.ast.NeoLangToken

/**
 * @author kiva
 */
class NeoLangStringNode(token: NeoLangToken) : NeoLangTokenBasedNode(token)