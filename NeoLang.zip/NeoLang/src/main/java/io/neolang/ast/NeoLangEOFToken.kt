package io.neolang.ast

/**
 * @author kiva
 */
class NeoLangEOFToken : NeoLangToken(NeoLangTokenType.EOF, NeoLangTokenValue.EOF)