package io.neolang.ast.node

import io.neolang.ast.NeoLangToken

/**
 * @author kiva
 */
class NeoLangNumberNode(token: NeoLangToken) : NeoLangTokenBasedNode(token)