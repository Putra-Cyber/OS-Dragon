package io.neolang.ast.base

open class NeoLangBaseNode : NeoLangAst()
