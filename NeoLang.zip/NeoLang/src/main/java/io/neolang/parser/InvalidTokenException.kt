package io.neolang.parser

/**
 * @author kiva
 */
open class InvalidTokenException(message: String) : ParseException(message)