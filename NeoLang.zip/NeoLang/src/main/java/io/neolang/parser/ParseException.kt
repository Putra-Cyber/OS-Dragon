package io.neolang.parser

/**
 * @author kiva
 */
open class ParseException(message: String) : RuntimeException(message)